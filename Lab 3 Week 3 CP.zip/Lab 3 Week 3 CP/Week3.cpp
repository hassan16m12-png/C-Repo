////Muhammad Hassan L1F26BSCS0309
//                          |------------Task 1--------------|
// #include<iostream>
// using namespace std;
//
//int main()
//{
//	cout << "Hello World!" << endl;
//	// Using \n in statement so only one cout is used
//	cout << "University of Central Punjab \nFaculty of Information Technology \nOrientation Day 2026"<<endl<<"Welcome!"<<endl;
//	cout << "2026" << endl;
//	cout << "45" << endl;
//	//multipling the exressions
//	cout << 45*3 << endl;
//	cout << 1000 + 500 - 250 << endl;
//	//writing the total fees by adding two digits
//	cout << "Total fee: " << 45000 + 9000 << endl;
//}
//                          |------------Task 2--------------|
// #include<iostream>
// using namespace std;
//int main()
//{
//	cout << "Orientation Day" << endl; //expected a ';'
//	cout << "Total students: " <<450 << endl;// '<<': unable to resolve function overload
//	cout << "Seats left: " << 500 - 450 << endl;
//	cout << "Have a nice day "<< endl; // Missing quotes
//	cout << "Average: " << (60 + 70 + 80) / 3 << endl; // the brackets will go between 60 and 80
//		return 0;
//}
//                          |------------Task 3--------------|
// #include<iostream>
// using namespace std;
// int main()
// {
// 	cout << "Expression 1:" << 10 + 5 * 2 << endl;
// 	cout << "Expression 2:" << (10 + 5) * 2 << endl;
// 	cout << "Expression 3:" << 20 - 5 - 3 << endl;
// 	cout << "Expression 4:" << 100 / 7 << endl;
// 	cout << "Expression 5:" << 100 % 7 << endl;
// 	cout << "Expression 6:" << 2 *( 3 + 8 / 4 - 1) << endl;
// }
//                          |------------Task 4--------------|
// #include<iostream>
// using namespace std;
// int main()
// {
// 	int Rollno = 1045, Sem = 1, fee = 45000, fee_paid = 20000;
// 	float Gpa = 3.5;
// 	char Section = 'B';
// 	cout<<"Roll No: "<< Rollno<< endl;
// 	cout<<"Semester: "<< Sem<< endl;
// 	cout<<"Section: "<< Section<< endl;
// 	cout<<"CGPA: "<< Gpa<< endl;
// 	cout<<"Total Fee: "<< fee<< endl;
// 	cout<<"Fee Paid: "<< fee_paid<< endl;
// 	Sem = Sem + 1;
// 	fee_paid = fee_paid + 5000;
// 	cout<<"Semester: "<< Sem<< endl;
// 	cout<<"Fee Paid: "<< fee_paid<< endl;
// 	cout<< "Remaining Fee: "<< fee - fee_paid<< endl;
// 	cout<< "Percentage Paid: "<< (fee_paid*100/fee)<< endl;
// 	/*2ndYear = InValid, student_name= Valid, total-marks = InValid, _fee = Valid, Roll No = Invalid, marks2 = Valid*/
// }
//                          |------------Task 5--------------|
// #include<iostream>
// using namespace std;
// int main()
// {
//     int age,creditHours,feePerCreditHour, total_fee;
//     cout<< "Enter Your Age: ";
//     cin>> age;
//     cout<< "Enter Number of Credit Hours: ";
//     cin>> creditHours;
//     cout<< "Enter Your Fee per Credit Hour: ";
//     cin>> feePerCreditHour;
//     total_fee = creditHours * feePerCreditHour;
//     cout<< "Total Fee: "<< total_fee << endl;
//     cout << "Fee after Discount: "<< total_fee - 2000 << endl;
//     cout << "Your Birth Year is: "<< 2026 - age << endl;
//     cout << "You will turn 25 in: "<< (2026-age)+25 << endl;
//     //It does not matter if i type the values by adding spaces, tabs or even pressing enter, each time i get the same output 
//     // When i type 19.8 in age the program executes but i did not get the required output
// }
//                          |------------Task 6--------------|
// #include<iostream>
// using namespace std;
// int main()
// {
//     int price = 0 ,quantity = 0, total = 0, tax = 0, grand_total = 0;
//     cout << "Enter price and quantity: ";
//     cin >> price;
//     cin>> quantity;
//     total = price * quantity;
//     tax = total * 5 / 100;
//     grand_total = total + tax;
//     cout << "Total = "<< total<<endl;
//     cout << "Tax = "<< tax<<endl;
//     cout << "Grand Total = "<< grand_total<<endl;
//     /* when i type price as 99 and quatity as 7, the tax shows to be 34 but 
//     if we use a calculator we get 34.65
//     This is because we have declared an integer variable as tax
//      so it only store the value before the point */
// }
//                          |------------Task 7--------------|
// #include<iostream>
// using namespace std;
// int main()
// {
//     float cel = 0;
//     float fah = 0.0;
//     cout<< "Enter Temperature in Celsius: ";
//     cin>> cel;
//     fah = cel *9/5 + 32;
//     cout << "Fahrenheit = "<< fah << endl;
// }